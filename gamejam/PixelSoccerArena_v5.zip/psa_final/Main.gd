## ============================================================
## PIXEL SOCCER ARENA  —  Weapons & Powers
## Un solo script · extends Node2D · Godot 4.6
## ============================================================
extends Node2D

const RW = 1280.0
const RH = 720.0

# ── PALETA ──────────────────────────────────────────────────
const C_BLACK    = Color(0.06, 0.04, 0.08)
const C_WHITE    = Color(0.93, 0.90, 0.85)
const C_YELLOW   = Color(0.95, 0.82, 0.10)
const C_ORANGE   = Color(0.95, 0.45, 0.05)
const C_RED      = Color(0.85, 0.10, 0.08)
const C_CYAN     = Color(0.35, 0.88, 0.98)
const C_MAGENTA  = Color(0.95, 0.10, 0.70)

const C_PURPLE   = Color(0.549, 0.102, 0.902, 1.0)
const C_PURPLE_D = Color(0.25, 0.03, 0.42)
const C_PURPLE_L = Color(0.80, 0.50, 1.00)
const C_SKIN_P   = Color(0.95, 0.78, 0.60)
const C_HAIR_P   = Color(0.15, 0.09, 0.04)
const C_SHIRT_P  = Color(0.42, 0.07, 0.78)
const C_PANTS_P  = Color(0.16, 0.07, 0.30)
const C_SHOE_P   = Color(0.08, 0.05, 0.12)

const C_GREEN    = Color(0.15, 0.80, 0.25)
const C_GREEN_D  = Color(0.05, 0.30, 0.10)
const C_GREEN_L  = Color(0.50, 1.00, 0.55)
const C_SKIN_G   = Color(0.88, 0.65, 0.45)
const C_HAIR_G   = Color(0.08, 0.05, 0.03)
const C_SHIRT_G  = Color(0.10, 0.65, 0.20)
const C_PANTS_G  = Color(0.06, 0.22, 0.10)
const C_SHOE_G   = Color(0.04, 0.08, 0.04)

const C_GRASS_A  = Color(0.10, 0.28, 0.08)
const C_GRASS_B  = Color(0.08, 0.22, 0.06)
const C_LINE     = Color(0.88, 0.85, 0.75)

# ── CAMPO (agrandado 10%) ──────────────────────────────────
const FIELD_LEFT  = 58.0
const FIELD_RIGHT = 1222.0
const FIELD_TOP   = 60.0
const FIELD_BOT   = 649.0
const GOAL_H      = 165.0
const GOAL_DEPTH  = 52.0
const GOAL_Y_TOP  = 282.0
const GOAL_Y_BOT  = 447.0

# ── CONSTANTES ──────────────────────────────────────────────
const PLAYER_SPEED     = 255.0
const BALL_FRICTION    = 0.984
const KICK_FORCE       = 680.0
const MAX_SCORE        = 5
const MATCH_TIME       = 180.0
const POWERUP_INTERVAL = 9.0

# ── ARMAS ───────────────────────────────────────────────────
const WEAPONS : Dictionary = {
	"pistola":    {"label":"PISTOLA",  "color":C_WHITE,   "speed":620.0, "stun":1.2, "cd":0.45, "ammo":10,  "effect":"normal"},
	"escopeta":   {"label":"ESCOPETA", "color":C_YELLOW,  "speed":500.0, "stun":1.8, "cd":1.10, "ammo":6,   "effect":"spread"},
	"cohete":     {"label":"COHETE",   "color":C_ORANGE,  "speed":380.0, "stun":2.5, "cd":2.00, "ammo":3,   "effect":"explode"},
	"congelador": {"label":"CRYO",     "color":C_CYAN,    "speed":450.0, "stun":3.0, "cd":0.90, "ammo":8,   "effect":"freeze"},
	"rayo":       {"label":"RAYO",     "color":C_MAGENTA, "speed":900.0, "stun":2.0, "cd":0.30, "ammo":5,   "effect":"chain"},
	"gravedad":   {"label":"GRAVEDAD", "color":Color(0.50, 0.20, 0.90), "speed":350.0, "stun":2.2, "cd":1.50, "ammo":4, "effect":"gravity"},
	"escudo":     {"label":"ESCUDO",   "color":Color(0.30, 0.85, 1.00), "speed":0.0,   "stun":0.0, "cd":0.0,  "ammo":1, "effect":"shield"},
	"vacia":      {"label":"VACIA",    "color":C_RED,     "speed":0.0,   "stun":0.0, "cd":0.0,  "ammo":0,   "effect":"none"},
}

# ── FUENTE PIXEL 5×5 ────────────────────────────────────────
const FONT_5X5 : Dictionary = {
	"A":["01110","10001","11111","10001","10001"],
	"B":["11110","10001","11110","10001","11110"],
	"C":["01111","10000","10000","10000","01111"],
	"D":["11100","10010","10001","10010","11100"],
	"E":["11111","10000","11110","10000","11111"],
	"F":["11111","10000","11110","10000","10000"],
	"G":["01111","10000","10011","10001","01111"],
	"H":["10001","10001","11111","10001","10001"],
	"I":["111","010","010","010","111"],
	"J":["00011","00001","00001","10001","01110"],
	"K":["10010","10100","11000","10100","10010"],
	"L":["10000","10000","10000","10000","11111"],
	"M":["10001","11011","10101","10001","10001"],
	"N":["10001","11001","10101","10011","10001"],
	"O":["01110","10001","10001","10001","01110"],
	"P":["11110","10001","11110","10000","10000"],
	"Q":["01110","10001","10101","10010","01101"],
	"R":["11110","10001","11110","10010","10001"],
	"S":["01111","10000","01110","00001","11110"],
	"T":["11111","00100","00100","00100","00100"],
	"U":["10001","10001","10001","10001","01110"],
	"V":["10001","10001","01010","01010","00100"],
	"W":["10001","10001","10101","11011","10001"],
	"X":["10001","01010","00100","01010","10001"],
	"Y":["10001","01010","00100","00100","00100"],
	"Z":["11111","00010","00100","01000","11111"],
	"0":["01110","10011","10101","11001","01110"],
	"1":["00100","01100","00100","00100","01110"],
	"2":["01110","10001","00110","01000","11111"],
	"3":["11110","00001","00110","00001","11110"],
	"4":["00010","00110","01010","11111","00010"],
	"5":["11111","10000","11110","00001","11110"],
	"6":["01110","10000","11110","10001","01110"],
	"7":["11111","00001","00010","00100","00100"],
	"8":["01110","10001","01110","10001","01110"],
	"9":["01110","10001","01111","00001","01110"],
	" ":["000","000","000","000","000"],
	"/":["00001","00010","00100","01000","10000"],
	"+":["000","010","111","010","000"],
	"-":["000","000","111","000","000"],
	"!":["1","1","1","0","1"],
	"|":["1","1","1","1","1"],
	":":["00","01","00","01","00"],
}

# ── ESTADO ──────────────────────────────────────────────────
var screen        : String  = "title"
var score         : Array   = [0, 0]
var match_time    : float   = MATCH_TIME
var active        : bool    = false
var goal_cooldown : float   = 0.0
var powerup_timer : float   = 0.0
var game_over     : bool    = false
var anim_t        : float   = 0.0

var p_names : Array[String] = ["JUGADOR 1", "JUGADOR 2"]

var gol_t    : float  = 0.0
var gol_team : int    = 0
var gol_name : String = ""

var gexp_t    : float = 0.0
var gexp_team : int   = 0

var players           : Array = []
var ball_pos          : Vector2 = Vector2(640, 360)
var ball_vel          : Vector2 = Vector2.ZERO
var ball_spin         : float   = 0.0
var bullets           : Array = []
var powerups_on_field : Array = []
var explosions        : Array = []
var goal_flash        : float = 0.0
var goal_flash_team   : int   = 0
var gravity_wells     : Array = []

var logo_tex : ImageTexture = null

var lbl_score    : Label
var lbl_timer    : Label
var lbl_p1_hud   : Label
var lbl_p2_hud   : Label
var lbl_center   : Label
var lbl_controls : Label
var lbl_pwlegend : Label
var lbl_p1_name_hud : Label
var lbl_p2_name_hud : Label

var name_panel  : ColorRect   # ya no se usa, se reemplaza por setup_panel
var setup_panel : ColorRect
var edit_p1     : LineEdit
var edit_p2     : LineEdit
var pause_block  : ColorRect

# Teclas configurables
var p1_shoot_key : int = KEY_F
var p1_kick_key  : int = KEY_G
var p2_shoot_key : int = KEY_K
var p2_kick_key  : int = KEY_L

# Botones de captura de tecla
var btn_p1_shoot : Button
var btn_p1_kick  : Button
var btn_p2_shoot : Button
var btn_p2_kick  : Button

# Qué botón está esperando input (-1 = ninguno)
# 0=p1shoot 1=p1kick 2=p2shoot 3=p2kick
var waiting_key_for : int = -1
var quit_confirm    : bool = false   # overlay "¿salir del juego?"

# ── READY ─────────────────────────────────────────────────
func _ready() -> void:
	_ensure_input_map()
	_load_logo()
	_build_ui()
	screen = "title"          # Título primero
	setup_panel.visible = false
	_set_game_ui(false)
	set_physics_process(true)
	set_process(true)

func _load_logo() -> void:
	if ResourceLoader.exists("res://logo.png"):
		var img := Image.load_from_file("res://logo.png")
		if img:
			logo_tex = ImageTexture.create_from_image(img)

# ── SETUP (nombres + teclas) ────────────────────────────
func _on_start_pressed() -> void:
	var n1 := edit_p1.text.strip_edges().to_upper()
	var n2 := edit_p2.text.strip_edges().to_upper()
	p_names[0] = n1 if n1 != "" else "JUGADOR 1"
	p_names[1] = n2 if n2 != "" else "JUGADOR 2"
	_remap_keys()
	setup_panel.visible = false
	waiting_key_for = -1
	screen = "game"
	_start_match()

func _on_key_btn_pressed(slot: int) -> void:
	waiting_key_for = slot
	# Resaltar el botón activo
	var btns := [btn_p1_shoot, btn_p1_kick, btn_p2_shoot, btn_p2_kick]
	for i in btns.size():
		if btns[i] != null:
			btns[i].text = "[ PRESIONA UNA TECLA ]" if i == slot else _key_name_for(i)

func _input(event: InputEvent) -> void:
	if screen != "setup" or waiting_key_for < 0: return
	if not (event is InputEventKey): return
	var ke := event as InputEventKey
	if not ke.pressed: return
	# Ignorar modificadores solos
	if ke.physical_keycode in [KEY_SHIFT, KEY_CTRL, KEY_ALT, KEY_META, KEY_ESCAPE]: return
	match waiting_key_for:
		0: p1_shoot_key = ke.physical_keycode
		1: p1_kick_key  = ke.physical_keycode
		2: p2_shoot_key = ke.physical_keycode
		3: p2_kick_key  = ke.physical_keycode
	waiting_key_for = -1
	# Actualizar texto de los botones
	_refresh_key_buttons()
	get_viewport().set_input_as_handled()

func _key_name_for(slot: int) -> String:
	var k : int
	match slot:
		0: k = p1_shoot_key
		1: k = p1_kick_key
		2: k = p2_shoot_key
		3: k = p2_kick_key
		_: k = KEY_NONE
	return OS.get_keycode_string(k)

func _refresh_key_buttons() -> void:
	if btn_p1_shoot: btn_p1_shoot.text = _key_name_for(0)
	if btn_p1_kick:  btn_p1_kick.text  = _key_name_for(1)
	if btn_p2_shoot: btn_p2_shoot.text = _key_name_for(2)
	if btn_p2_kick:  btn_p2_kick.text  = _key_name_for(3)

func _remap_keys() -> void:
	var map : Dictionary = {
		"p1_up":KEY_W, "p1_down":KEY_S, "p1_left":KEY_A, "p1_right":KEY_D,
		"p1_shoot": p1_shoot_key, "p1_kick": p1_kick_key,
		"p2_up":KEY_UP, "p2_down":KEY_DOWN, "p2_left":KEY_LEFT, "p2_right":KEY_RIGHT,
		"p2_shoot": p2_shoot_key, "p2_kick": p2_kick_key,
		"pause":KEY_SPACE,
	}
	for action : String in map.keys():
		if not InputMap.has_action(action): InputMap.add_action(action)
		InputMap.action_erase_events(action)
		var ev := InputEventKey.new(); ev.physical_keycode = map[action] as Key
		InputMap.action_add_event(action, ev)

# ── START / RESET ────────────────────────────────────────
func _start_match() -> void:
	screen        = "game"
	score         = [0, 0]
	match_time    = MATCH_TIME
	active        = true
	game_over     = false
	goal_cooldown = 0.0
	powerup_timer = 0.0
	gol_t         = 0.0
	gexp_t        = 0.0
	bullets.clear()
	powerups_on_field.clear()
	explosions.clear()
	gravity_wells.clear()
	players   = [_make_player(Vector2(300, 360), 0), _make_player(Vector2(980, 360), 1)]
	ball_pos  = Vector2(640, 360)
	ball_vel  = Vector2.ZERO
	ball_spin = 0.0
	lbl_center.text = ""
	lbl_p1_name_hud.text = p_names[0]
	lbl_p2_name_hud.text = p_names[1]
	# Actualizar controles en HUD con teclas elegidas
	var k_s1 := OS.get_keycode_string(p1_shoot_key)
	var k_k1 := OS.get_keycode_string(p1_kick_key)
	var k_s2 := OS.get_keycode_string(p2_shoot_key)
	var k_k2 := OS.get_keycode_string(p2_kick_key)
	lbl_controls.text = "MORADO: WASD + %s dispara + %s patear     |     VERDE: Flechas + %s dispara + %s patear     |     ESPACIO = Pausa" % [k_s1, k_k1, k_s2, k_k2]
	pause_block.visible = false
	_set_game_ui(true)

func _make_player(pos: Vector2, team: int) -> Dictionary:
	return {
		"pos": pos, "vel": Vector2.ZERO, "team": team,
		"stun": false, "stun_t": 0.0, "shoot_cd": 0.0,
		"weapon": "pistola", "ammo": 10, "pistol_ammo": 10,
		"frozen": false, "freeze_t": 0.0,
		"facing": Vector2(1 if team == 0 else -1, 0),
		"moving": false, "walk_t": 0.0,
		"has_ball": false,
		"shield": false, "shield_t": 0.0,
	}

func _set_game_ui(on: bool) -> void:
	lbl_score.visible       = on
	lbl_timer.visible       = on
	lbl_p1_hud.visible      = on
	lbl_p2_hud.visible      = on
	lbl_controls.visible    = on
	lbl_pwlegend.visible    = on
	lbl_center.visible      = on
	lbl_p1_name_hud.visible = on
	lbl_p2_name_hud.visible = on

# ── PROCESS ──────────────────────────────────────────────
func _process(delta: float) -> void:
	anim_t += delta

	# ESC global (excepto cuando se espera tecla para reasignar)
	var esc_pressed := Input.is_action_just_pressed("quit_action") and waiting_key_for < 0

	match screen:
		"title":
			if esc_pressed:
				# ESC en título → confirmar salida
				quit_confirm = not quit_confirm
			elif quit_confirm:
				# Con confirm abierto: F/K/ENTER confirman salida
				if Input.is_action_just_pressed("p1_shoot") or Input.is_action_just_pressed("p2_shoot") \
				or Input.is_action_just_pressed("p1_kick")  or Input.is_action_just_pressed("p2_kick"):
					get_tree().quit()
			elif Input.is_anything_pressed():
				quit_confirm = false
				setup_panel.visible = true
				screen = "setup"
				_set_game_ui(false)

		"setup":
			if esc_pressed:
				# ESC en setup → volver al título
				setup_panel.visible = false
				screen = "title"
				quit_confirm = false

		"game":
			if Input.is_action_just_pressed("pause") or esc_pressed:
				screen = "paused"
				pause_block.visible = true

		"paused":
			if Input.is_action_just_pressed("pause"):
				screen = "game"
				pause_block.visible = false
			elif esc_pressed:
				# ESC en pausa → volver al título (sin setup)
				screen = "title"
				pause_block.visible = false
				active = false
				_set_game_ui(false)
				quit_confirm = false

		"end":
			if Input.is_action_just_pressed("p1_shoot") or Input.is_action_just_pressed("p2_shoot") \
			or Input.is_action_just_pressed("p1_kick")  or Input.is_action_just_pressed("p2_kick") \
			or Input.is_action_just_pressed("pause") or esc_pressed:
				setup_panel.visible = true
				screen = "setup"
				_set_game_ui(false)
				quit_confirm = false

	queue_redraw()

# ── PHYSICS ──────────────────────────────────────────────
func _physics_process(delta: float) -> void:
	if screen != "game" or not active or game_over: return

	if gol_t   > 0.0: gol_t   -= delta
	if gexp_t  > 0.0: gexp_t  -= delta
	if goal_flash > 0.0: goal_flash -= delta

	goal_cooldown -= delta
	if goal_cooldown > 0.0: return

	match_time -= delta
	if match_time <= 0.0:
		match_time = 0.0; _end_match(); return

	powerup_timer += delta
	if powerup_timer >= POWERUP_INTERVAL:
		powerup_timer = 0.0; _spawn_powerup()

	_update_players(delta)
	_update_ball(delta)
	_update_bullets(delta)
	_update_powerups()
	_check_goal()
	_update_explosions(delta)
	_update_gravity_wells(delta)
	_update_hud()

# ── JUGADORES ────────────────────────────────────────────
func _update_players(delta: float) -> void:
	for i in 2:
		var p   : Dictionary = players[i]
		var pfx : String     = "p%d_" % (i + 1)

		if p["stun_t"]   > 0.0: p["stun_t"]   -= delta; if p["stun_t"]   <= 0.0: p["stun"]   = false
		if p["freeze_t"] > 0.0: p["freeze_t"] -= delta; if p["freeze_t"] <= 0.0: p["frozen"] = false
		if p["shield_t"] > 0.0: p["shield_t"] -= delta; if p["shield_t"] <= 0.0: p["shield"] = false
		if p["shoot_cd"] > 0.0: p["shoot_cd"] -= delta

		if p["stun"] or p["frozen"]:
			p["vel"]    = (p["vel"] as Vector2).lerp(Vector2.ZERO, delta * 10.0)
			p["pos"]    = (p["pos"] as Vector2) + (p["vel"] as Vector2) * delta
			p["moving"] = false
			_clamp_player(p); continue

		var dir := Vector2.ZERO
		if Input.is_action_pressed(pfx + "up"):    dir.y -= 1
		if Input.is_action_pressed(pfx + "down"):  dir.y += 1
		if Input.is_action_pressed(pfx + "left"):  dir.x -= 1
		if Input.is_action_pressed(pfx + "right"): dir.x += 1
		if dir != Vector2.ZERO: dir = dir.normalized(); p["facing"] = dir

		p["moving"]  = dir != Vector2.ZERO
		p["vel"]     = dir * PLAYER_SPEED
		p["pos"]     = (p["pos"] as Vector2) + (p["vel"] as Vector2) * delta
		if p["moving"]: p["walk_t"] = (p["walk_t"] as float) + delta
		_clamp_player(p)

		if Input.is_action_just_pressed(pfx + "shoot") and (p["shoot_cd"] as float) <= 0.0 and (p["ammo"] as int) > 0 and (p["weapon"] as String) != "vacia":
			_shoot(p)
		if Input.is_action_just_pressed(pfx + "kick"):
			_kick(p)

		# ── COLISIÓN CON PELOTA: cuerpo completo ──
		# El sprite mide ~55px de alto; el centro del cuerpo está ~25px arriba del pivot
		var body_center : Vector2 = (p["pos"] as Vector2) + Vector2(0.0, -25.0)
		var dist : float = body_center.distance_to(ball_pos)
		# Radio = ~38px cubre cabeza+torso+piernas
		if dist < 38.0 and dist > 0.5:
			var push_dir : Vector2 = (ball_pos - body_center).normalized()
			var overlap   : float  = 38.0 - dist
			ball_pos += push_dir * (overlap * 0.65)
			ball_vel += push_dir * (90.0 + (p["vel"] as Vector2).length() * 0.55)
			ball_vel += (p["vel"] as Vector2) * 0.45

func _clamp_player(p: Dictionary) -> void:
	var pos := p["pos"] as Vector2
	pos.x    = clamp(pos.x, FIELD_LEFT + 16, FIELD_RIGHT - 16)
	pos.y    = clamp(pos.y, FIELD_TOP  + 16, FIELD_BOT   - 16)
	p["pos"] = pos

func _shoot(p: Dictionary) -> void:
	var w : Dictionary = WEAPONS[p["weapon"]]

	# Escudo: se activa al instante, no dispara bala
	if (w["effect"] as String) == "shield":
		p["shield"]   = true
		p["shield_t"] = 4.5
		p["ammo"]     = 0
		# Volver a pistola con balas restantes
		if (p["pistol_ammo"] as int) > 0:
			p["weapon"] = "pistola"
			p["ammo"]   = p["pistol_ammo"]
		else:
			p["weapon"] = "vacia"
			p["ammo"]   = 0
		return

	p["shoot_cd"] = w["cd"]
	p["ammo"]     = (p["ammo"] as int) - 1
	# Rastrear balas de pistola restantes
	if (p["weapon"] as String) == "pistola":
		p["pistol_ammo"] = p["ammo"]
	if (p["ammo"] as int) <= 0:
		if (p["weapon"] as String) == "pistola":
			# Pistola agotada: sin recarga para toda la partida
			p["weapon"] = "vacia"
			p["ammo"]   = 0
		else:
			# Arma especial agotada: vuelve a pistola con balas restantes
			if (p["pistol_ammo"] as int) > 0:
				p["weapon"] = "pistola"
				p["ammo"]   = p["pistol_ammo"]
			else:
				p["weapon"] = "vacia"
				p["ammo"]   = 0

	var rival_idx : int    = 1 - (p["team"] as int)
	var rpos      : Vector2 = players[rival_idx]["pos"] as Vector2
	var aim_dir   : Vector2 = (rpos - (p["pos"] as Vector2)).normalized()
	p["facing"] = aim_dir

	if (w["effect"] as String) == "spread":
		for a : int in [-18, -9, 0, 9, 18]:
			var d : Vector2 = aim_dir.rotated(deg_to_rad(float(a)))
			bullets.append({"pos": (p["pos"] as Vector2) + d * 30.0,
				"vel": d * (w["speed"] as float), "team": p["team"],
				"weapon": p["weapon"], "life": 2.0})
	elif (w["effect"] as String) == "gravity":
		# Crea un pozo gravitacional en el campo
		gravity_wells.append({
			"pos": ball_pos,
			"life": 3.5,
			"team": p["team"],
			"radius": 120.0,
			"force": 480.0,
		})
		bullets.append({"pos": (p["pos"] as Vector2) + aim_dir * 30.0,
			"vel": aim_dir * (w["speed"] as float), "team": p["team"],
			"weapon": p["weapon"], "life": 2.0})
	elif (w["effect"] as String) == "chain":
		# Rayo: dispara en línea directa muy rápido
		for k in 3:
			var delay_offset : Vector2 = aim_dir * float(k) * 18.0
			bullets.append({"pos": (p["pos"] as Vector2) + aim_dir * 30.0 + delay_offset,
				"vel": aim_dir * (w["speed"] as float), "team": p["team"],
				"weapon": p["weapon"], "life": 1.5})
	else:
		bullets.append({"pos": (p["pos"] as Vector2) + aim_dir * 30.0,
			"vel": aim_dir * (w["speed"] as float), "team": p["team"],
			"weapon": p["weapon"], "life": 2.0})

func _kick(p: Dictionary) -> void:
	if (p["pos"] as Vector2).distance_to(ball_pos) < 62.0:
		ball_vel += ((ball_pos - (p["pos"] as Vector2)).normalized()) * KICK_FORCE

# ── PELOTA ───────────────────────────────────────────────
func _update_ball(delta: float) -> void:
	ball_pos  += ball_vel * delta
	ball_vel  *= BALL_FRICTION
	ball_spin += ball_vel.length() * delta * 0.8
	if ball_pos.y < FIELD_TOP  + 14: ball_pos.y = FIELD_TOP  + 14; ball_vel.y =  absf(ball_vel.y) * 0.7
	if ball_pos.y > FIELD_BOT  - 14: ball_pos.y = FIELD_BOT  - 14; ball_vel.y = -absf(ball_vel.y) * 0.7
	if ball_pos.x < FIELD_LEFT + 14:
		if ball_pos.y < GOAL_Y_TOP or ball_pos.y > GOAL_Y_BOT:
			ball_pos.x = FIELD_LEFT + 14; ball_vel.x = absf(ball_vel.x) * 0.7
	if ball_pos.x > FIELD_RIGHT - 14:
		if ball_pos.y < GOAL_Y_TOP or ball_pos.y > GOAL_Y_BOT:
			ball_pos.x = FIELD_RIGHT - 14; ball_vel.x = -absf(ball_vel.x) * 0.7
	if ball_pos.x < FIELD_LEFT  - GOAL_DEPTH: ball_pos.x = FIELD_LEFT  - GOAL_DEPTH; ball_vel.x =  absf(ball_vel.x) * 0.5
	if ball_pos.x > FIELD_RIGHT + GOAL_DEPTH: ball_pos.x = FIELD_RIGHT + GOAL_DEPTH; ball_vel.x = -absf(ball_vel.x) * 0.5
	if ball_vel.length() > 960.0: ball_vel = ball_vel.normalized() * 960.0

# ── POZOS GRAVITACIONALES ──────────────────────────────
func _update_gravity_wells(delta: float) -> void:
	var rm : Array = []
	for gw : Dictionary in gravity_wells:
		gw["life"] = (gw["life"] as float) - delta
		if (gw["life"] as float) <= 0.0: rm.append(gw); continue
		var gwp : Vector2 = gw["pos"] as Vector2
		var dist : float  = ball_pos.distance_to(gwp)
		if dist < (gw["radius"] as float) and dist > 5.0:
			var pull : Vector2 = (gwp - ball_pos).normalized()
			ball_vel += pull * (gw["force"] as float) * delta
		for p : Dictionary in players:
			var pd : float = (p["pos"] as Vector2).distance_to(gwp)
			if pd < (gw["radius"] as float) and pd > 5.0 and (p["team"] as int) != (gw["team"] as int):
				var ppull : Vector2 = (gwp - (p["pos"] as Vector2)).normalized()
				p["vel"] = (p["vel"] as Vector2) + ppull * 180.0 * delta
				p["pos"] = (p["pos"] as Vector2) + (p["vel"] as Vector2) * delta
				_clamp_player(p)
	for gw in rm: gravity_wells.erase(gw)

# ── BALAS ────────────────────────────────────────────────
func _update_bullets(delta: float) -> void:
	var rm : Array = []
	for b : Dictionary in bullets:
		b["pos"]  = (b["pos"] as Vector2) + (b["vel"] as Vector2) * delta
		b["life"] = (b["life"] as float)  - delta
		var bpos : Vector2 = b["pos"] as Vector2
		if (b["life"] as float) <= 0 or bpos.x < 0 or bpos.x > RW or bpos.y < 0 or bpos.y > RH:
			rm.append(b); continue
		var w : Dictionary = WEAPONS[b["weapon"]]
		if bpos.distance_to(ball_pos) < 18.0:
			if (w["effect"] as String) == "explode":
				ball_vel += (ball_pos - bpos).normalized() * 900.0; _add_explosion(bpos)
			else:
				ball_vel += (b["vel"] as Vector2).normalized() * 420.0
			rm.append(b); continue
		var hit := false
		for p : Dictionary in players:
			if (p["team"] as int) == (b["team"] as int): continue
			if bpos.distance_to(p["pos"] as Vector2) < 22.0:
				# Escudo: rebota la bala de vuelta
				if p["shield"] as bool:
					b["vel"] = -(b["vel"] as Vector2) * 0.85
					b["team"] = p["team"] as int
					break
				match (w["effect"] as String):
					"freeze": p["frozen"] = true;  p["freeze_t"] = w["stun"]
					"chain":
						p["stun"] = true; p["stun_t"] = w["stun"]
						_add_explosion(bpos)
					_:        p["stun"]   = true;  p["stun_t"]   = w["stun"]
				if (w["effect"] as String) == "explode": _add_explosion(bpos)
				rm.append(b); hit = true; break
		if hit: continue
		if bpos.y < FIELD_TOP or bpos.y > FIELD_BOT: rm.append(b)
	for b : Dictionary in rm: bullets.erase(b)

# ── POWER-UPS ────────────────────────────────────────────
func _update_powerups() -> void:
	var rm : Array = []
	for pw : Dictionary in powerups_on_field:
		for p : Dictionary in players:
			if (p["pos"] as Vector2).distance_to(pw["pos"] as Vector2) < 28.0:
				p["weapon"] = pw["weapon"]; p["ammo"] = WEAPONS[pw["weapon"] as String]["ammo"]
				rm.append(pw); break
	for pw : Dictionary in rm: powerups_on_field.erase(pw)

func _spawn_powerup() -> void:
	if powerups_on_field.size() >= 3: return
	var ws : Array[String] = ["escopeta", "cohete", "congelador", "rayo", "gravedad", "escudo"]
	powerups_on_field.append({
		"pos": Vector2(randf_range(FIELD_LEFT + 100, FIELD_RIGHT - 100),
					   randf_range(FIELD_TOP + 60,  FIELD_BOT - 60)),
		"weapon": ws[randi() % ws.size()],
	})

# ── GOLES ────────────────────────────────────────────────
func _check_goal() -> void:
	if ball_pos.x < FIELD_LEFT  - 10 and ball_pos.y > GOAL_Y_TOP and ball_pos.y < GOAL_Y_BOT: _score_goal(1)
	if ball_pos.x > FIELD_RIGHT + 10 and ball_pos.y > GOAL_Y_TOP and ball_pos.y < GOAL_Y_BOT: _score_goal(0)

func _score_goal(team: int) -> void:
	score[team]    = (score[team] as int) + 1
	goal_flash     = 1.6
	goal_flash_team = team
	goal_cooldown  = 2.6

	gol_t    = 2.4
	gol_team = team
	gol_name = p_names[team]

	gexp_t    = 0.55
	gexp_team = 1 - team

	ball_pos = Vector2(640, 360); ball_vel = Vector2.ZERO
	players[0]["pos"] = Vector2(300, 360); players[1]["pos"] = Vector2(980, 360)
	for p : Dictionary in players:
		p["vel"] = Vector2.ZERO; p["stun"] = false; p["frozen"] = false
		p["shield"] = false; p["shield_t"] = 0.0
	gravity_wells.clear()

	if (score[team] as int) >= MAX_SCORE:
		get_tree().create_timer(2.2).timeout.connect(func(): _end_match())

func _end_match() -> void:
	active = false; game_over = true; screen = "end"
	var s0 : int = score[0]; var s1 : int = score[1]
	var msg : String
	if   s0 > s1: msg = "GANA %s!\n%d - %d" % [p_names[0], s0, s1]; lbl_center.add_theme_color_override("font_color", C_PURPLE_L)
	elif s1 > s0: msg = "GANA %s!\n%d - %d" % [p_names[1], s0, s1]; lbl_center.add_theme_color_override("font_color", C_GREEN_L)
	else:         msg = "EMPATE!\n%d - %d"   % [s0, s1];              lbl_center.add_theme_color_override("font_color", C_YELLOW)
	lbl_center.text = msg + "\n\nF  o  K  para continuar"

# ── EXPLOSIONES ──────────────────────────────────────────
func _add_explosion(pos: Vector2) -> void:
	explosions.append({"pos": pos, "radius": 6.0, "life": 0.40, "max_life": 0.40})

func _update_explosions(delta: float) -> void:
	var rm : Array = []
	for e : Dictionary in explosions:
		e["life"]   = (e["life"] as float) - delta
		e["radius"] = remap(e["life"] as float, 0.0, e["max_life"] as float, 85.0, 6.0)
		if (e["life"] as float) <= 0.0: rm.append(e)
	for e : Dictionary in rm: explosions.erase(e)

# ── HUD ──────────────────────────────────────────────────
func _update_hud() -> void:
	lbl_score.text = "%d  -  %d" % [score[0], score[1]]
	var m : int = int(match_time) / 60; var s : int = int(match_time) % 60
	lbl_timer.text = "%d:%02d" % [m, s]
	lbl_timer.add_theme_color_override("font_color", C_RED if match_time < 30 else C_WHITE)
	var p1 : Dictionary = players[0]; var p2 : Dictionary = players[1]
	var st1 : String = " [STUN]" if (p1["stun"] as bool) else (" [CRYO]" if (p1["frozen"] as bool) else "")
	var st2 : String = " [STUN]" if (p2["stun"] as bool) else (" [CRYO]" if (p2["frozen"] as bool) else "")
	if (p1["weapon"] as String) == "vacia":
		lbl_p1_hud.text = "[ SIN BALAS ]" + st1
		lbl_p1_hud.add_theme_color_override("font_color", C_RED)
	else:
		lbl_p1_hud.text = "[ %s x%d ]%s" % [(WEAPONS[p1["weapon"]] as Dictionary)["label"], p1["ammo"], st1]
		lbl_p1_hud.add_theme_color_override("font_color", C_WHITE)
	if (p2["weapon"] as String) == "vacia":
		lbl_p2_hud.text = "[ SIN BALAS ]" + st2
		lbl_p2_hud.add_theme_color_override("font_color", C_RED)
	else:
		lbl_p2_hud.text = "[ %s x%d ]%s" % [(WEAPONS[p2["weapon"]] as Dictionary)["label"], p2["ammo"], st2]
		lbl_p2_hud.add_theme_color_override("font_color", C_WHITE)

# ═══════════════════════════════════════════════════════════
#  DIBUJO
# ═══════════════════════════════════════════════════════════
func _draw() -> void:
	match screen:
		"title":  _draw_title()
		"setup":  _draw_setup_bg()
		"game":   _draw_game()
		"paused": _draw_game(); _draw_pause()
		"end":    _draw_end()

func _draw_setup_bg() -> void:
	# Fondo degradado oscuro con rayas de pasto
	draw_rect(Rect2(0, 0, RW, RH), C_BLACK)
	for i in 10:
		var alpha : float = float(i) / 10.0
		draw_rect(Rect2(0, float(i) * (RH/10.0), RW, RH/10.0),
			Color(C_GRASS_A.r, C_GRASS_A.g, C_GRASS_A.b, alpha * 0.18))
	# Línea central decorativa
	draw_line(Vector2(640, 0), Vector2(640, RH), Color(C_LINE.r, C_LINE.g, C_LINE.b, 0.06), 2.0)
	draw_arc(Vector2(640, 360), 90, 0, TAU, 64, Color(C_LINE.r, C_LINE.g, C_LINE.b, 0.06), 1.5)

func _draw_title() -> void:
	# ── Fondo con campo de fútbol estilizado ──
	draw_rect(Rect2(0, 0, RW, RH), Color(0.04, 0.06, 0.03))

	# Franjas de césped animadas
	for i in 12:
		var c : Color = C_GRASS_A if i % 2 == 0 else C_GRASS_B
		draw_rect(Rect2(0, float(i) * (RH/12.0), RW, RH/12.0), c)

	# Líneas del campo
	var fl : float = 80.0; var fr : float = 1200.0
	var ft : float = 80.0; var fb : float = 640.0
	draw_rect(Rect2(fl, ft, fr-fl, fb-ft), C_LINE, false, 2.0)
	draw_line(Vector2(640, ft), Vector2(640, fb), C_LINE, 2.0)
	draw_arc(Vector2(640, (ft+fb)*0.5), 80, 0, TAU, 48, C_LINE, 2.0)
	draw_circle(Vector2(640, (ft+fb)*0.5), 6, C_LINE)

	# ── Overlay oscuro encima del campo ──
	draw_rect(Rect2(0, 0, RW, RH), Color(0.0, 0.0, 0.0, 0.52))

	# ── Brillo central pulsante ──
	var glow : float = 0.10 + sin(anim_t * 1.8) * 0.04
	draw_circle(Vector2(640, 320), 380, Color(0.30, 0.08, 0.55, glow))
	draw_circle(Vector2(640, 320), 220, Color(0.20, 0.05, 0.40, glow * 1.4))

	# ── Logo / Título ──
	if logo_tex:
		var lw := 190.0; var lh := 190.0
		draw_texture_rect(logo_tex, Rect2((RW - lw)*0.5, 70.0, lw, lh), false)
	else:
		# Título pixel art centrado
		var title1 := "PIXEL SOCCER"
		var title2 := "ARENA"
		var t1w := _ptext_width(title1, 16.0)
		var t2w := _ptext_width(title2, 10.0)
		_draw_ptext(title1, (RW - t1w) * 0.5, 110.0, 16.0, C_YELLOW)
		_draw_ptext(title2, (RW - t2w) * 0.5, 200.0, 10.0, Color(C_YELLOW.r, C_YELLOW.g, C_YELLOW.b, 0.70))

	# Título con logo: "PIXEL SOCCER" grande + "ARENA" pequeño debajo
	if logo_tex:
		var t1 := "PIXEL  SOCCER"
		var t2 := "ARENA"
		var t1w2 := _ptext_width(t1, 11.0)
		var t2w2 := _ptext_width(t2, 7.0)
		_draw_ptext(t1, (RW - t1w2) * 0.5, 278.0, 11.0, C_YELLOW)
		_draw_ptext(t2, (RW - t2w2) * 0.5, 305.0,  7.0, Color(C_YELLOW.r, C_YELLOW.g, C_YELLOW.b, 0.65))

	# ── Subtítulo centrado ──
	var sub := "WEAPONS  &  POWERS"
	var sw := _ptext_width(sub, 7.0)
	_draw_ptext(sub, (RW - sw) * 0.5, 400.0, 7.0, Color(0.75, 0.70, 0.60, 0.85))

	# ── Separador decorativo ──
	draw_line(Vector2(340, 428), Vector2(640-30, 428), Color(C_PURPLE.r, C_PURPLE.g, C_PURPLE.b, 0.6), 2.0)
	draw_line(Vector2(640+30, 428), Vector2(940, 428), Color(C_GREEN.r, C_GREEN.g, C_GREEN.b, 0.6), 2.0)
	_draw_ball_at(Vector2(640, 428), 12.0, fmod(anim_t * 30.0, 360.0))

	# ── Personajes pixel art a los lados ──
	_draw_character(Vector2(260, 560), 0, false, false, true, 2.8)
	_draw_character(Vector2(1020, 560), 1, false, false, true, 2.8)

	# ── Pelota al centro ──
	_draw_ball_at(Vector2(640, 530), 26.0, fmod(anim_t * 55.0, 360.0))

	# ── Texto parpadeante ──
	if fmod(anim_t, 1.1) < 0.72:
		var pw := _ptext_width("PRESIONA  CUALQUIER  TECLA", 7.5)
		_draw_ptext("PRESIONA  CUALQUIER  TECLA", (RW - pw) * 0.5, 635.0, 7.5, C_YELLOW)

	# ── Versión / controles mini ──
	_draw_ptext("WASD+teclas   |   FLECHAS+teclas", 360.0, 692.0, 5.0, Color(0.5, 0.5, 0.45, 0.55))

	# ── Overlay "¿Salir?" ──
	if quit_confirm:
		draw_rect(Rect2(0, 0, RW, RH), Color(0, 0, 0, 0.72))
		var pw2 := 560.0; var ph2 := 200.0
		var px2 := (RW - pw2) * 0.5; var py2 := (RH - ph2) * 0.5
		draw_rect(Rect2(px2+4, py2+4, pw2, ph2), Color(0, 0, 0, 0.55))
		draw_rect(Rect2(px2, py2, pw2, ph2), Color(0.10, 0.03, 0.16, 0.97))
		draw_rect(Rect2(px2, py2, pw2, ph2), C_RED, false, 3.5)
		var msg2 := "SALIR DEL JUEGO?"
		_draw_ptext(msg2, (RW - _ptext_width(msg2, 10.0)) * 0.5, py2 + 28.0, 10.0, C_RED)
		var sub2 := "F / K = SI          ESC = NO"
		_draw_ptext(sub2, (RW - _ptext_width(sub2, 6.0)) * 0.5, py2 + 88.0, 6.0, Color(0.80, 0.78, 0.72, 0.90))
		var pulse2 := 0.65 + sin(anim_t * 5.0) * 0.35
		_draw_ptext("SI", (RW - _ptext_width("SI", 13.0)) * 0.5 - 110.0, py2 + 128.0, 13.0, Color(C_RED.r, C_RED.g, C_RED.b, pulse2))
		_draw_ptext("NO", (RW - _ptext_width("NO", 13.0)) * 0.5 + 110.0, py2 + 128.0, 13.0, Color(C_GREEN_L.r, C_GREEN_L.g, C_GREEN_L.b, pulse2))

# ── JUEGO ────────────────────────────────────────────────
func _draw_game() -> void:
	_draw_field()
	_draw_goals()
	if gexp_t > 0.0: _draw_goal_explosion()
	_draw_gravity_wells_art()
	_draw_powerups_art()
	var sorted : Array = players.duplicate()
	sorted.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		return (a["pos"] as Vector2).y < (b["pos"] as Vector2).y)
	for p : Dictionary in sorted: _draw_player_char(p)
	_draw_ball_sprite()
	_draw_bullets_art()
	_draw_explosions_art()
	if goal_flash > 0.0:
		var gc : Color = C_PURPLE if goal_flash_team == 0 else C_GREEN
		draw_rect(Rect2(0, 0, RW, RH), Color(gc.r, gc.g, gc.b, goal_flash * 0.20))
	if gol_t > 0.0: _draw_gol_banner()

# ── POZOS GRAVITACIONALES ART ──────────────────────────
func _draw_gravity_wells_art() -> void:
	for gw : Dictionary in gravity_wells:
		var pos  : Vector2 = gw["pos"] as Vector2
		var life : float   = gw["life"] as float
		var rad  : float   = gw["radius"] as float
		var ratio : float  = clampf(life / 3.5, 0.0, 1.0)
		var pulse : float  = 0.7 + sin(anim_t * 8.0) * 0.3
		var col   : Color  = Color(0.50, 0.20, 0.90)
		for ring in 3:
			var r2 : float = (rad * (float(ring + 1) / 3.0)) * pulse
			draw_arc(pos, r2, 0, TAU, 32, Color(col.r, col.g, col.b, ratio * 0.25), 2.0)
		draw_circle(pos, 12.0 * pulse, Color(col.r, col.g, col.b, ratio * 0.8))
		draw_circle(pos, 6.0, Color(1.0, 0.8, 1.0, ratio))
		for j in 8:
			var a : float = TAU * float(j) / 8.0 + anim_t * 4.0
			var sp : Vector2 = pos + Vector2(cos(a), sin(a)) * rad * 0.5 * pulse
			draw_rect(Rect2(sp.x - 2, sp.y - 2, 4, 4), Color(col.r, col.g, col.b, ratio * 0.6))

# ── EXPLOSIÓN PORTERÍA ──────────────────────────────────
func _draw_goal_explosion() -> void:
	var ratio : float = gexp_t / 0.55
	var cx : float = FIELD_LEFT - GOAL_DEPTH * 0.5 if gexp_team == 0 else FIELD_RIGHT + GOAL_DEPTH * 0.5
	var cy : float = (GOAL_Y_TOP + GOAL_Y_BOT) * 0.5

	var spots : Array[Vector2] = [
		Vector2(cx, cy),
		Vector2(cx, GOAL_Y_TOP + 22.0),
		Vector2(cx, GOAL_Y_BOT - 22.0),
		Vector2(cx - 8.0, cy - 28.0),
		Vector2(cx + 8.0, cy + 28.0),
	]
	for idx in spots.size():
		var sp  : Vector2 = spots[idx]
		var ph  : float   = fmod(anim_t * 28.0 + float(idx) * 1.1, TAU)
		var r   : float   = (30.0 + sin(ph) * 12.0) * ratio
		draw_circle(sp, r,          Color(1.0, 0.85, 0.20, ratio * 0.72))
		draw_circle(sp, r * 0.62,   Color(1.0, 0.45, 0.08, ratio * 0.88))
		draw_circle(sp, r * 0.28,   Color(1.0, 1.00, 0.80, ratio))

	for j in 16:
		var a   : float   = TAU * float(j) / 16.0 + anim_t * 7.0
		var d   : float   = (45.0 + sin(anim_t * 14.0 + float(j)) * 18.0) * ratio
		var sp2 : Vector2 = Vector2(cx, cy) + Vector2(cos(a), sin(a)) * d
		draw_rect(Rect2(sp2.x - 3.0, sp2.y - 3.0, 6.0, 6.0), Color(1.0, 0.9, 0.3, ratio))

	var fc : Color = Color(1.0, 0.55, 0.05, ratio * (0.45 + sin(anim_t * 45.0) * 0.45))
	if gexp_team == 0:
		draw_rect(Rect2(FIELD_LEFT - GOAL_DEPTH, GOAL_Y_TOP, GOAL_DEPTH, GOAL_H), fc, false, 6.0)
		draw_line(Vector2(FIELD_LEFT, GOAL_Y_TOP), Vector2(FIELD_LEFT - GOAL_DEPTH, GOAL_Y_TOP), fc, 5.0)
		draw_line(Vector2(FIELD_LEFT, GOAL_Y_BOT), Vector2(FIELD_LEFT - GOAL_DEPTH, GOAL_Y_BOT), fc, 5.0)
	else:
		draw_rect(Rect2(FIELD_RIGHT, GOAL_Y_TOP, GOAL_DEPTH, GOAL_H), fc, false, 6.0)
		draw_line(Vector2(FIELD_RIGHT, GOAL_Y_TOP), Vector2(FIELD_RIGHT + GOAL_DEPTH, GOAL_Y_TOP), fc, 5.0)
		draw_line(Vector2(FIELD_RIGHT, GOAL_Y_BOT), Vector2(FIELD_RIGHT + GOAL_DEPTH, GOAL_Y_BOT), fc, 5.0)

# ── CARTEL GOL ───────────────────────────────────────────
func _draw_gol_banner() -> void:
	var ratio : float = clampf(gol_t / 2.4, 0.0, 1.0)
	var tc    : Color = C_PURPLE if gol_team == 0 else C_GREEN

	draw_rect(Rect2(193.0, 243.0, 896.0, 232.0), Color(0.0, 0.0, 0.0, 0.75 * ratio))
	draw_rect(Rect2(190.0, 240.0, 896.0, 232.0), Color(tc.r * 0.14, tc.g * 0.14, tc.b * 0.14, 0.94 * ratio))
	draw_rect(Rect2(190.0, 240.0, 896.0, 232.0), tc, false, 4.0)
	draw_rect(Rect2(195.0, 245.0, 886.0, 222.0), Color(tc.r, tc.g, tc.b, 0.18 * ratio), false, 2.0)

	var pulse : float = 1.0 + sin(anim_t * 14.0) * 0.07
	var sz    : float = 20.0 * pulse
	var gw    : float = _ptext_width("GOL!", sz)
	_draw_ptext("GOL!", (RW - gw) * 0.5, 264.0, sz, Color(tc.r, tc.g, tc.b, ratio))

	_draw_ball_at(Vector2(930.0, 318.0), 28.0, fmod(anim_t * 200.0, 360.0))

	var nm_sz : float = 9.0
	var nm_w  : float = _ptext_width(gol_name, nm_sz)
	_draw_ptext(gol_name, (RW - nm_w) * 0.5, 384.0, nm_sz, Color(1.0, 1.0, 1.0, ratio))

	var sc_str : String = "%d  -  %d" % [score[0], score[1]]
	var sc_w   : float  = _ptext_width(sc_str, 7.0)
	_draw_ptext(sc_str, (RW - sc_w) * 0.5, 432.0, 7.0, Color(C_YELLOW.r, C_YELLOW.g, C_YELLOW.b, ratio))

func _ptext_width(text: String, sz: float) -> float:
	var gap : float = sz * 1.3; var x : float = 0.0
	for ti in text.to_upper().length():
		var ch : String = text.to_upper().substr(ti, 1)
		if not FONT_5X5.has(ch): x += sz * 3 + gap; continue
		x += float((FONT_5X5[ch][0] as String).length()) * sz + gap
	return x

# ── PAUSA ────────────────────────────────────────────────
func _draw_pause() -> void:
	draw_rect(Rect2(0.0, 0.0, RW, RH), Color(0.0, 0.0, 0.0, 0.62))
	draw_rect(Rect2(388.0, 258.0, 504.0, 204.0), Color(0.06, 0.02, 0.12, 0.96))
	draw_rect(Rect2(388.0, 258.0, 504.0, 204.0), C_YELLOW, false, 3.0)
	var pw : float = _ptext_width("PAUSA", 14.0)
	_draw_ptext("PAUSA", (RW - pw) * 0.5, 298.0, 14.0, C_YELLOW)
	var ew : float = _ptext_width("ESPACIO PARA CONTINUAR", 6.0)
	_draw_ptext("ESPACIO PARA CONTINUAR", (RW - ew) * 0.5, 398.0, 6.0,
		Color(0.72, 0.72, 0.72, 0.9))

# ── FIN ──────────────────────────────────────────────────
func _draw_end() -> void:
	draw_rect(Rect2(0.0, 0.0, RW, RH), C_BLACK)
	draw_rect(Rect2(FIELD_LEFT, FIELD_TOP, FIELD_RIGHT - FIELD_LEFT, FIELD_BOT - FIELD_TOP),
		Color(0.06, 0.14, 0.04, 0.15))
	var win_team : int = 0 if (score[0] as int) >= (score[1] as int) else 1
	_draw_character(Vector2(RW * 0.5, 490.0), win_team, false, false, true, 3.2)
	if fmod(anim_t, 1.0) < 0.5:
		_draw_ptext("!", RW * 0.5 + 30.0, 340.0, 18.0, C_YELLOW)

# ── CAMPO ────────────────────────────────────────────────
func _draw_field() -> void:
	draw_rect(Rect2(0, 0, RW, RH), C_BLACK)
	var fw : float = FIELD_RIGHT - FIELD_LEFT; var fh : float = FIELD_BOT - FIELD_TOP
	for i in 8:
		var sx : float = FIELD_LEFT + float(i) * fw / 8.0
		draw_rect(Rect2(sx, FIELD_TOP, fw / 8.0, fh), C_GRASS_A if i % 2 == 0 else C_GRASS_B)
	draw_rect(Rect2(FIELD_LEFT, FIELD_TOP, fw, fh), C_LINE, false, 2.5)
	draw_line(Vector2(640, FIELD_TOP), Vector2(640, FIELD_BOT), C_LINE, 2.0)
	draw_arc(Vector2(640, 354), 72, 0, TAU, 48, C_LINE, 2.0)
	draw_circle(Vector2(640, 354), 5, C_LINE)
	draw_rect(Rect2(FIELD_LEFT, 246, 115, 218), C_LINE, false, 1.5)
	draw_rect(Rect2(FIELD_RIGHT - 115, 246, 115, 218), C_LINE, false, 1.5)
	for cx : float in [FIELD_LEFT, FIELD_RIGHT]:
		for cy : float in [FIELD_TOP, FIELD_BOT]:
			draw_arc(Vector2(cx, cy), 16, 0, TAU, 12, C_LINE, 1.5)

# ── PORTERÍAS ────────────────────────────────────────────
func _draw_goals() -> void:
	draw_rect(Rect2(FIELD_LEFT - GOAL_DEPTH, GOAL_Y_TOP, GOAL_DEPTH, GOAL_H),
		Color(C_PURPLE.r, C_PURPLE.g, C_PURPLE.b, 0.18))
	_draw_net(FIELD_LEFT - GOAL_DEPTH, GOAL_Y_TOP, GOAL_DEPTH, GOAL_H, C_PURPLE_D)
	draw_rect(Rect2(FIELD_LEFT - GOAL_DEPTH, GOAL_Y_TOP, GOAL_DEPTH, GOAL_H), C_PURPLE, false, 2.5)
	draw_line(Vector2(FIELD_LEFT, GOAL_Y_TOP), Vector2(FIELD_LEFT - GOAL_DEPTH, GOAL_Y_TOP), C_WHITE, 4.0)
	draw_line(Vector2(FIELD_LEFT, GOAL_Y_BOT), Vector2(FIELD_LEFT - GOAL_DEPTH, GOAL_Y_BOT), C_WHITE, 4.0)
	draw_line(Vector2(FIELD_LEFT - GOAL_DEPTH, GOAL_Y_TOP), Vector2(FIELD_LEFT - GOAL_DEPTH, GOAL_Y_BOT), C_WHITE, 4.0)
	_draw_post(Vector2(FIELD_LEFT, GOAL_Y_TOP)); _draw_post(Vector2(FIELD_LEFT, GOAL_Y_BOT))

	draw_rect(Rect2(FIELD_RIGHT, GOAL_Y_TOP, GOAL_DEPTH, GOAL_H),
		Color(C_GREEN.r, C_GREEN.g, C_GREEN.b, 0.18))
	_draw_net(FIELD_RIGHT, GOAL_Y_TOP, GOAL_DEPTH, GOAL_H, C_GREEN_D)
	draw_rect(Rect2(FIELD_RIGHT, GOAL_Y_TOP, GOAL_DEPTH, GOAL_H), C_GREEN, false, 2.5)
	draw_line(Vector2(FIELD_RIGHT, GOAL_Y_TOP), Vector2(FIELD_RIGHT + GOAL_DEPTH, GOAL_Y_TOP), C_WHITE, 4.0)
	draw_line(Vector2(FIELD_RIGHT, GOAL_Y_BOT), Vector2(FIELD_RIGHT + GOAL_DEPTH, GOAL_Y_BOT), C_WHITE, 4.0)
	draw_line(Vector2(FIELD_RIGHT + GOAL_DEPTH, GOAL_Y_TOP), Vector2(FIELD_RIGHT + GOAL_DEPTH, GOAL_Y_BOT), C_WHITE, 4.0)
	_draw_post(Vector2(FIELD_RIGHT, GOAL_Y_TOP)); _draw_post(Vector2(FIELD_RIGHT, GOAL_Y_BOT))

func _draw_post(pos: Vector2) -> void:
	draw_circle(pos, 6, C_WHITE); draw_circle(pos, 4, Color(0.6, 0.6, 0.6))

func _draw_net(nx: float, ny: float, nw: float, nh: float, col: Color) -> void:
	var nc : Color = Color(col.r, col.g, col.b, 0.55); var step : float = 14.0
	var x : float = nx
	while x <= nx + nw: draw_line(Vector2(x, ny), Vector2(x, ny + nh), nc, 1.0); x += step
	var y : float = ny
	while y <= ny + nh: draw_line(Vector2(nx, y), Vector2(nx + nw, y), nc, 1.0); y += step

# ── POWER-UPS ART ────────────────────────────────────────
func _draw_powerups_art() -> void:
	for pw : Dictionary in powerups_on_field:
		var w : Dictionary = WEAPONS[pw["weapon"] as String]
		var pos : Vector2  = pw["pos"] as Vector2
		var pulse : float  = sin(anim_t * 3.5) * 3.5
		draw_circle(pos, 19.0 + pulse, Color((w["color"] as Color).r, (w["color"] as Color).g, (w["color"] as Color).b, 0.20))
		var bx : float = pos.x - 11.0; var by : float = pos.y - 11.0
		draw_rect(Rect2(bx - 2, by - 2, 26, 26), Color(0.04, 0.04, 0.07))
		draw_rect(Rect2(bx - 2, by - 2, 26, 26), w["color"] as Color, false, 1.5)
		match (pw["weapon"] as String):
			"escopeta":   _draw_icon_shotgun(bx, by, w["color"] as Color)
			"cohete":     _draw_icon_rocket(bx, by, w["color"] as Color)
			"congelador": _draw_icon_cryo(bx, by, w["color"] as Color)
			"rayo":       _draw_icon_lightning(bx, by, w["color"] as Color)
			"gravedad":   _draw_icon_gravity(bx, by, w["color"] as Color)
			"escudo":     _draw_icon_shield(bx, by, w["color"] as Color)
		# SIN letras — solo el icono

func _draw_icon_shotgun(x: float, y: float, col: Color) -> void:
	draw_rect(Rect2(x+2, y+7, 16, 5), col); draw_rect(Rect2(x+2, y+3, 5, 4), col)
	draw_rect(Rect2(x+4, y+12, 9, 4), col); draw_rect(Rect2(x+17, y+6, 4, 7), Color(col.r, col.g, col.b, 0.7))

func _draw_icon_rocket(x: float, y: float, col: Color) -> void:
	draw_rect(Rect2(x+2, y+7, 13, 6), col); draw_rect(Rect2(x+15, y+6, 5, 8), col)
	draw_rect(Rect2(x+2, y+4, 4, 3), col);  draw_rect(Rect2(x+2, y+13, 4, 3), col)
	draw_rect(Rect2(x, y+8, 3, 4), Color(1.0, 0.5, 0.1, 0.6 + sin(anim_t * 18.0) * 0.4))

func _draw_icon_cryo(x: float, y: float, col: Color) -> void:
	draw_rect(Rect2(x+8, y+1, 4, 18), col);  draw_rect(Rect2(x+1, y+8, 18, 4), col)
	draw_rect(Rect2(x+3, y+3, 4, 4), col);   draw_rect(Rect2(x+13, y+3, 4, 4), col)
	draw_rect(Rect2(x+3, y+13, 4, 4), col);  draw_rect(Rect2(x+13, y+13, 4, 4), col)

func _draw_icon_lightning(x: float, y: float, col: Color) -> void:
	# Rayo en zigzag
	draw_rect(Rect2(x+12, y+1, 5, 8), col)
	draw_rect(Rect2(x+6,  y+7, 10, 5), col)
	draw_rect(Rect2(x+3,  y+10, 8, 8), col)
	draw_rect(Rect2(x+8,  y+16, 5, 4), col)
	draw_circle(Vector2(x+14, y+4), 2.0, Color(1.0, 1.0, 0.6, 0.7 + sin(anim_t*20.0)*0.3))

func _draw_icon_gravity(x: float, y: float, col: Color) -> void:
	# Espiral / anillos concéntricos
	draw_arc(Vector2(x+10, y+10), 9.0, 0, TAU, 16, col, 2.0)
	draw_arc(Vector2(x+10, y+10), 5.0, 0, TAU, 12, col, 2.0)
	draw_circle(Vector2(x+10, y+10), 2.5, Color(1.0, 0.8, 1.0, 0.8 + sin(anim_t*8.0)*0.2))

func _draw_icon_shield(x: float, y: float, col: Color) -> void:
	# Escudo heráldico
	var pts := PackedVector2Array([
		Vector2(x+2,y+2), Vector2(x+20,y+2), Vector2(x+20,y+12),
		Vector2(x+11,y+20), Vector2(x+2,y+12),
	])
	draw_colored_polygon(pts, Color(col.r, col.g, col.b, 0.45))
	draw_polyline(pts, col, 2.5, true)
	# Cruz interior
	draw_rect(Rect2(x+9, y+5, 4, 10), col)
	draw_rect(Rect2(x+5, y+9, 12, 3), col)

# ── PELOTA ───────────────────────────────────────────────
func _draw_ball_sprite() -> void:
	_draw_ball_at(ball_pos, 13.0, fmod(ball_spin, 360.0))

func _draw_ball_at(pos: Vector2, r: float, spin_deg: float) -> void:
	draw_circle(Vector2(pos.x+4, pos.y+4), r, Color(0,0,0,0.28))
	draw_circle(pos, r, C_WHITE)
	var ang : float = deg_to_rad(spin_deg)
	for pv : Vector2 in [Vector2(0,0), Vector2(0,-r*0.62), Vector2(r*0.55,r*0.32), Vector2(-r*0.55,r*0.32)]:
		draw_circle(pos + pv.rotated(ang), r*0.28 if pv == Vector2.ZERO else r*0.22, C_BLACK)
	draw_circle(Vector2(pos.x - r*0.3, pos.y - r*0.35), r*0.22, Color(1,1,1,0.55))

# ── BALAS ART ─────────────────────────────────────────────
func _draw_bullets_art() -> void:
	for b : Dictionary in bullets:
		var pos : Vector2 = b["pos"] as Vector2
		var dir : Vector2 = (b["vel"] as Vector2).normalized()
		var perp: Vector2 = Vector2(-dir.y, dir.x)
		match (b["weapon"] as String):
			"pistola":
				draw_rect(Rect2(pos.x-3, pos.y-2, 7, 4), C_YELLOW)
				draw_rect(Rect2(pos.x+3, pos.y-1, 4, 2), Color(1.0,0.9,0.6))
				draw_line(pos, pos - dir*10.0, Color(1.0,0.9,0.4,0.45), 2.0)
			"escopeta":
				draw_circle(pos, 5, C_YELLOW); draw_circle(pos, 3, Color(1.0,1.0,0.7))
				draw_line(pos, pos - dir*9.0, Color(1.0,0.8,0.3,0.5), 3.0)
			"cohete":
				var tip := pos + dir*9.0; var tail := pos - dir*9.0
				draw_colored_polygon(PackedVector2Array([tip, tail+perp*5.0, tail-perp*5.0]), C_ORANGE)
				var fa : float = 0.6 + sin(anim_t*20.0)*0.4
				draw_colored_polygon(PackedVector2Array([tail, tail-dir*9.0+perp*3.5, tail-dir*9.0-perp*3.5]),
					Color(1.0, 0.5, 0.1, fa))
			"congelador":
				draw_circle(pos, 6, C_CYAN); draw_circle(pos, 3, Color(0.8,1.0,1.0))
				draw_line(pos, pos - dir*14.0, Color(0.4,0.9,1.0,0.45), 2.5)
			"rayo":
				# Rayo con chispa eléctrica
				draw_circle(pos, 5, C_MAGENTA); draw_circle(pos, 3, Color(1.0, 0.8, 1.0))
				draw_line(pos, pos - dir*16.0, Color(0.9, 0.2, 0.9, 0.6), 3.0)
				draw_line(pos, pos + dir*8.0,  Color(1.0, 1.0, 1.0, 0.8), 2.0)
			"gravedad":
				draw_circle(pos, 7, Color(0.50,0.20,0.90,0.8))
				draw_circle(pos, 4, Color(0.8,0.5,1.0,0.9))
				for j in 4:
					var a2 : float = TAU * float(j) / 4.0 + anim_t * 12.0
					var sp2 : Vector2 = pos + Vector2(cos(a2), sin(a2)) * 10.0
					draw_circle(sp2, 2.0, Color(0.6,0.2,0.9,0.7))

# ── EXPLOSIONES ART ───────────────────────────────────────
func _draw_explosions_art() -> void:
	for e : Dictionary in explosions:
		var t   : float   = (e["life"] as float) / (e["max_life"] as float)
		var pos : Vector2 = e["pos"] as Vector2; var rad : float = e["radius"] as float
		draw_circle(pos, rad, Color(1.0,0.85,0.2,t*0.70)); draw_circle(pos, rad*0.65, Color(1.0,0.50,0.1,t*0.90))
		draw_circle(pos, rad*0.30, Color(1.0,1.00,0.8,t))
		for i in 8:
			var a : float = TAU*float(i)/8.0 + anim_t*9.0
			var sp : Vector2 = pos + Vector2(cos(a),sin(a))*rad*0.88
			draw_rect(Rect2(sp.x-2, sp.y-2, 4, 4), Color(1.0,0.9,0.4,t))

# ── PERSONAJE PIXEL ART ──────────────────────────────────
func _draw_character(pos: Vector2, team: int, stun: bool, frozen: bool, moving: bool, scale: float = 1.6) -> void:
	var U := scale
	var c_skin  : Color = C_SKIN_P  if team == 0 else C_SKIN_G
	var c_hair  : Color = C_HAIR_P  if team == 0 else C_HAIR_G
	var c_shirt : Color = C_SHIRT_P if team == 0 else C_SHIRT_G
	var c_pants : Color = C_PANTS_P if team == 0 else C_PANTS_G
	var c_shoe  : Color = C_SHOE_P  if team == 0 else C_SHOE_G
	var c_team  : Color = C_PURPLE  if team == 0 else C_GREEN
	if frozen: c_shirt = C_CYAN;   c_pants = Color(0.5, 0.9, 1.0)
	if stun:   c_shirt = C_YELLOW; c_pants = Color(0.8, 0.7, 0.1)
	var bob  : float = sin(anim_t*10.0)*1.5*U if moving else 0.0
	var leg1 : float = sin(anim_t*10.0)*2.5*U if moving else 0.0
	var leg2 : float = -leg1
	draw_circle(Vector2(pos.x, pos.y+2.0), 11.0*U, Color(0,0,0,0.32))
	_r(pos.x-4*U, pos.y-14*U+leg1, 4*U, 11*U, c_pants); _r(pos.x, pos.y-14*U+leg2, 4*U, 11*U, c_pants)
	_r(pos.x-6*U, pos.y-4*U+leg1, 7*U, 4*U, c_shoe);   _r(pos.x-1*U, pos.y-4*U+leg2, 7*U, 4*U, c_shoe)
	_r(pos.x-5*U, pos.y-6*U+leg1, 3*U, 3*U, c_shoe);   _r(pos.x, pos.y-6*U+leg2, 3*U, 3*U, c_shoe)
	_r(pos.x-7*U, pos.y-27*U+bob, 14*U, 13*U, c_shirt)
	_r(pos.x-7*U, pos.y-25*U+bob, 14*U, 2*U, c_team)
	_r(pos.x-7*U, pos.y-16*U+bob, 14*U, 2*U, Color(c_shirt.r*0.7, c_shirt.g*0.7, c_shirt.b*0.7))
	_r(pos.x-11*U, pos.y-26*U+leg2*0.5, 4*U, 10*U, c_shirt)
	_r(pos.x+7*U,  pos.y-26*U+leg1*0.5, 4*U, 10*U, c_shirt)
	_r(pos.x-12*U, pos.y-18*U+leg2*0.5, 5*U, 5*U, c_skin)
	_r(pos.x+7*U,  pos.y-18*U+leg1*0.5, 5*U, 5*U, c_skin)
	_r(pos.x-2*U, pos.y-30*U+bob, 4*U, 4*U, c_skin)
	var hx : float = pos.x-8*U; var hy : float = pos.y-46*U+bob*0.35
	_r(hx, hy, 16*U, 16*U, c_skin)
	_r(hx-1*U, hy-3*U, 18*U, 5*U, c_hair); _r(hx-1*U, hy, 2*U, 9*U, c_hair); _r(hx+15*U, hy, 2*U, 9*U, c_hair)
	if frozen:
		_r(hx+2*U, hy+6*U, 5*U, 2*U, c_hair); _r(hx+9*U, hy+6*U, 5*U, 2*U, c_hair)
	elif stun:
		for ox : float in [2.0, 9.0]:
			_r(hx+ox*U, hy+4*U, 2*U, 2*U, C_RED); _r(hx+(ox+2)*U, hy+6*U, 2*U, 2*U, C_RED)
			_r(hx+(ox+2)*U, hy+4*U, 2*U, 2*U, C_RED); _r(hx+ox*U, hy+6*U, 2*U, 2*U, C_RED)
	else:
		_r(hx+2*U, hy+4*U, 5*U, 5*U, Color(0.95,0.95,0.95)); _r(hx+9*U, hy+4*U, 5*U, 5*U, Color(0.95,0.95,0.95))
		var iris : Color = Color(0.20,0.45,0.80) if team==0 else Color(0.15,0.65,0.20)
		_r(hx+3*U, hy+5*U, 3*U, 3*U, iris); _r(hx+10*U, hy+5*U, 3*U, 3*U, iris)
		_r(hx+4*U, hy+6*U, 1*U, 1*U, c_hair); _r(hx+11*U, hy+6*U, 1*U, 1*U, c_hair)
		_r(hx+3*U, hy+4*U, 1*U, 1*U, C_WHITE); _r(hx+10*U, hy+4*U, 1*U, 1*U, C_WHITE)
	_r(hx+7*U, hy+8*U, 2*U, 3*U, Color(c_skin.r*0.82, c_skin.g*0.72, c_skin.b*0.62))
	if stun: _r(hx+3*U, hy+12*U, 10*U, 2*U, Color(0.5,0.1,0.1))
	else:
		_r(hx+4*U, hy+12*U, 8*U, 2*U, Color(c_skin.r*0.6, c_skin.g*0.5, c_skin.b*0.5))
		for ox2 : float in [5.0, 7.0, 9.0]: _r(hx+ox2*U, hy+12*U, 2*U, 2*U, C_WHITE)
	_r(hx+2*U, hy+2*U, 5*U, 1*U, c_hair); _r(hx+9*U, hy+2*U, 5*U, 1*U, c_hair)
	_draw_ptext("1" if team==0 else "2", pos.x-2*U, pos.y-24*U+bob, 1.6*U, C_WHITE)

func _r(x: float, y: float, w: float, h: float, col: Color) -> void:
	draw_rect(Rect2(x, y, maxf(w, 1.0), maxf(h, 1.0)), col)

func _draw_player_char(p: Dictionary) -> void:
	var pos    : Vector2 = p["pos"] as Vector2
	var team   : int     = p["team"] as int
	var flip   : bool    = (p["facing"] as Vector2).x < -0.1

	# Aura de escudo
	if p["shield"] as bool:
		var sa : float = 0.50 + sin(anim_t * 8.0) * 0.30
		draw_circle(pos + Vector2(0, -22), 36.0, Color(0.30, 0.85, 1.00, sa * 0.25))
		draw_arc(pos + Vector2(0, -22), 36.0, anim_t * 3.0, anim_t * 3.0 + TAU, 32,
			Color(0.30, 0.85, 1.00, sa), 3.0)

	if flip: draw_set_transform(Vector2(pos.x*2.0, 0.0), 0.0, Vector2(-1,1))
	_draw_character(pos, team, p["stun"] as bool, p["frozen"] as bool, p["moving"] as bool, 1.6)
	if flip: draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	var wname : String = p["weapon"] as String
	if wname != "pistola" and wname != "vacia":
		var w  : Dictionary = WEAPONS[wname]
		var wx : float = pos.x-11.0; var wy : float = pos.y-82.0
		draw_rect(Rect2(wx-2, wy-2, 26, 26), Color(0.03,0.03,0.06))
		draw_rect(Rect2(wx-2, wy-2, 26, 26), w["color"] as Color, false, 1.5)
		match wname:
			"escopeta":   _draw_icon_shotgun(wx, wy, w["color"] as Color)
			"cohete":     _draw_icon_rocket(wx, wy, w["color"] as Color)
			"congelador": _draw_icon_cryo(wx, wy, w["color"] as Color)
			"rayo":       _draw_icon_lightning(wx, wy, w["color"] as Color)
			"gravedad":   _draw_icon_gravity(wx, wy, w["color"] as Color)
			"escudo":     _draw_icon_shield(wx, wy, w["color"] as Color)
	elif wname == "vacia":
		# Icono de sin balas: X roja pequeña
		var wx : float = pos.x-10.0; var wy : float = pos.y-82.0
		draw_rect(Rect2(wx-2, wy-2, 24, 24), Color(0.12,0.02,0.02))
		draw_rect(Rect2(wx-2, wy-2, 24, 24), C_RED, false, 1.5)
		draw_line(Vector2(wx+2,wy+2), Vector2(wx+18,wy+18), C_RED, 3.0)
		draw_line(Vector2(wx+18,wy+2), Vector2(wx+2,wy+18), C_RED, 3.0)
	var bx : float = pos.x-16.0; var by : float = pos.y+8.0
	var stun_key : String = "stun_t" if (p["stun"] as bool) else "freeze_t"
	var bar_col  : Color  = C_YELLOW if (p["stun"] as bool) else C_CYAN
	if (p["stun"] as bool) or (p["frozen"] as bool):
		# Usar stun seguro (puede ser de cualquier arma que ya no tiene)
		var max_stun : float = 1.5  # valor seguro por defecto
		if wname != "vacia" and WEAPONS.has(wname):
			max_stun = maxf((WEAPONS[wname]["stun"] as float), 0.01)
		draw_rect(Rect2(bx, by, 32, 6), Color(0.06,0.06,0.10))
		draw_rect(Rect2(bx, by, 32, 6), bar_col, false, 1.0)
		var ratio : float = clampf((p[stun_key] as float) / max_stun, 0.0, 1.0)
		draw_rect(Rect2(bx, by, 32.0*ratio, 6), bar_col)

# ── TEXTO PIXEL ──────────────────────────────────────────
func _draw_ptext(text: String, ox: float, oy: float, sz: float, col: Color) -> void:
	var gap : float = sz * 1.3; var x : float = ox
	for ti in text.to_upper().length():
		var ch : String = text.to_upper().substr(ti, 1)
		if not FONT_5X5.has(ch): x += sz*3+gap; continue
		var rows : Array = FONT_5X5[ch]; var cw : int = (rows[0] as String).length()
		for ri in rows.size():
			var row : String = rows[ri] as String
			for ci in row.length():
				if row.substr(ci,1) == "1":
					draw_rect(Rect2(x+float(ci)*sz, oy+float(ri)*sz*1.25, sz, sz), col)
		x += float(cw)*sz + gap

# ── UI ───────────────────────────────────────────────────
func _build_ui() -> void:
	var cl := CanvasLayer.new(); add_child(cl)

	# ── Barra superior — más alta para caber todo ──
	var top := ColorRect.new()
	top.color = Color(0.04, 0.02, 0.08, 0.92)
	top.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top.custom_minimum_size = Vector2(0, 68); top.size = Vector2(1280, 68)
	cl.add_child(top)

	# ── Marcador grande centrado (el más prominente) ──
	lbl_score = _mk_label("0  -  0", Vector2(0, 2), 42, C_YELLOW, cl)
	lbl_score.set_anchors_preset(Control.PRESET_TOP_WIDE)
	lbl_score.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_score.size = Vector2(1280, 50)

	# ── Tiempo debajo del marcador, centrado ──
	lbl_timer = _mk_label("3:00", Vector2(0, 48), 17, C_WHITE, cl)
	lbl_timer.set_anchors_preset(Control.PRESET_TOP_WIDE)
	lbl_timer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_timer.size = Vector2(1280, 24)

	# ── Nombre P1 a la izquierda ──
	lbl_p1_name_hud = _mk_label("", Vector2(10, 4), 16, C_PURPLE_L, cl)
	lbl_p1_name_hud.size = Vector2(380, 32)

	# ── Nombre P2 a la derecha ──
	lbl_p2_name_hud = _mk_label("", Vector2(890, 4), 16, C_GREEN_L, cl)
	lbl_p2_name_hud.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	lbl_p2_name_hud.size = Vector2(380, 32)

	# ── Armas HUD (debajo del nombre, izq/der) ──
	lbl_p1_hud = _mk_label("[ PISTOLA x10 ]", Vector2(10, 36), 13, C_WHITE, cl)
	lbl_p1_hud.size = Vector2(380, 24)
	lbl_p2_hud = _mk_label("[ PISTOLA x10 ]", Vector2(890, 36), 13, C_WHITE, cl)
	lbl_p2_hud.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	lbl_p2_hud.size = Vector2(380, 24)

	lbl_center = _mk_label("", Vector2(-420,-70), 42, C_YELLOW, cl)
	lbl_center.set_anchors_preset(Control.PRESET_CENTER)
	lbl_center.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_center.size = Vector2(840, 180); lbl_center.autowrap_mode = TextServer.AUTOWRAP_WORD

	lbl_controls = _mk_label(
		"MORADO: WASD + F dispara + G patear     |     VERDE: Flechas + K dispara + L patear     |     ESPACIO = Pausa",
		Vector2(0,-22), 11, Color(0.55,0.55,0.55,0.70), cl)
	lbl_controls.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	lbl_controls.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	lbl_pwlegend = _mk_label("Power-ups:  Escopeta  |  Cohete  |  Cryo  |  Rayo  |  Gravedad  |  Escudo",
		Vector2(0,-38), 12, Color(0.70,0.68,0.40,0.65), cl)
	lbl_pwlegend.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	lbl_pwlegend.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	# ── Pantalla de configuración (setup) ──
	setup_panel = ColorRect.new()
	setup_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	setup_panel.color = Color(0.03, 0.02, 0.08, 0.97)
	cl.add_child(setup_panel)

	# Logo pequeño arriba
	if logo_tex:
		var trect2 := TextureRect.new()
		trect2.texture      = logo_tex
		trect2.position     = Vector2((1280-120)*0.5, 14)
		trect2.size         = Vector2(120, 120)
		trect2.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		setup_panel.add_child(trect2)

	# Título
	var st := Label.new()
	st.text = "CONFIGURACIÓN"
	st.set_anchors_preset(Control.PRESET_TOP_WIDE)
	st.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	st.position = Vector2(0, 144)
	st.add_theme_font_size_override("font_size", 36)
	st.add_theme_color_override("font_color", C_YELLOW)
	setup_panel.add_child(st)

	var st2 := Label.new()
	st2.text = "Haz clic en un botón y presiona la tecla que deseas asignar"
	st2.set_anchors_preset(Control.PRESET_TOP_WIDE)
	st2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	st2.position = Vector2(0, 188)
	st2.add_theme_font_size_override("font_size", 14)
	st2.add_theme_color_override("font_color", Color(0.65, 0.65, 0.60, 0.85))
	setup_panel.add_child(st2)

	# Separador
	var sep := ColorRect.new()
	sep.color = Color(0.30, 0.12, 0.55, 0.60)
	sep.position = Vector2(180, 218); sep.size = Vector2(920, 2)
	setup_panel.add_child(sep)

	var col1x := 140.0
	var col2x := 700.0
	var ry    := 236.0

	# ── JUGADOR 1 ──
	var lh1 := Label.new(); lh1.text = "◈  JUGADOR 1  —  MORADO"
	lh1.position = Vector2(col1x, ry)
	lh1.add_theme_font_size_override("font_size", 18)
	lh1.add_theme_color_override("font_color", C_PURPLE_L)
	setup_panel.add_child(lh1)

	var ln1 := Label.new(); ln1.text = "Nombre:"
	ln1.position = Vector2(col1x, ry+40); ln1.add_theme_font_size_override("font_size", 13)
	ln1.add_theme_color_override("font_color", C_WHITE); setup_panel.add_child(ln1)
	edit_p1 = LineEdit.new(); edit_p1.placeholder_text = "Jugador 1"
	edit_p1.position = Vector2(col1x, ry+60); edit_p1.size = Vector2(400, 44)
	edit_p1.add_theme_font_size_override("font_size", 20); setup_panel.add_child(edit_p1)

	var ls1 := Label.new(); ls1.text = "DISPARAR  (clic y presiona tecla):"
	ls1.position = Vector2(col1x, ry+120); ls1.add_theme_font_size_override("font_size", 13)
	ls1.add_theme_color_override("font_color", C_WHITE); setup_panel.add_child(ls1)
	btn_p1_shoot = _mk_keybtn(col1x, ry+142, 190, setup_panel, "F", 0)

	var lk1 := Label.new(); lk1.text = "PATEAR:"
	lk1.position = Vector2(col1x+210, ry+120); lk1.add_theme_font_size_override("font_size", 13)
	lk1.add_theme_color_override("font_color", C_WHITE); setup_panel.add_child(lk1)
	btn_p1_kick = _mk_keybtn(col1x+210, ry+142, 180, setup_panel, "G", 1)

	var lmv1 := Label.new(); lmv1.text = "Movimiento:  W  A  S  D"
	lmv1.position = Vector2(col1x, ry+198); lmv1.add_theme_font_size_override("font_size", 13)
	lmv1.add_theme_color_override("font_color", Color(C_PURPLE_L.r, C_PURPLE_L.g, C_PURPLE_L.b, 0.70))
	setup_panel.add_child(lmv1)

	# ── Divisor central ──
	var div := ColorRect.new()
	div.color = Color(0.22, 0.22, 0.22, 0.55)
	div.position = Vector2(628, 232); div.size = Vector2(2, 260)
	setup_panel.add_child(div)

	# ── JUGADOR 2 ──
	var lh2 := Label.new(); lh2.text = "◈  JUGADOR 2  —  VERDE"
	lh2.position = Vector2(col2x, ry)
	lh2.add_theme_font_size_override("font_size", 18)
	lh2.add_theme_color_override("font_color", C_GREEN_L)
	setup_panel.add_child(lh2)

	var ln2 := Label.new(); ln2.text = "Nombre:"
	ln2.position = Vector2(col2x, ry+40); ln2.add_theme_font_size_override("font_size", 13)
	ln2.add_theme_color_override("font_color", C_WHITE); setup_panel.add_child(ln2)
	edit_p2 = LineEdit.new(); edit_p2.placeholder_text = "Jugador 2"
	edit_p2.position = Vector2(col2x, ry+60); edit_p2.size = Vector2(400, 44)
	edit_p2.add_theme_font_size_override("font_size", 20); setup_panel.add_child(edit_p2)

	var ls2 := Label.new(); ls2.text = "DISPARAR  (clic y presiona tecla):"
	ls2.position = Vector2(col2x, ry+120); ls2.add_theme_font_size_override("font_size", 13)
	ls2.add_theme_color_override("font_color", C_WHITE); setup_panel.add_child(ls2)
	btn_p2_shoot = _mk_keybtn(col2x, ry+142, 190, setup_panel, "K", 2)

	var lk2 := Label.new(); lk2.text = "PATEAR:"
	lk2.position = Vector2(col2x+210, ry+120); lk2.add_theme_font_size_override("font_size", 13)
	lk2.add_theme_color_override("font_color", C_WHITE); setup_panel.add_child(lk2)
	btn_p2_kick = _mk_keybtn(col2x+210, ry+142, 180, setup_panel, "L", 3)

	var lmv2 := Label.new(); lmv2.text = "Movimiento:  ↑  ↓  ←  →"
	lmv2.position = Vector2(col2x, ry+198); lmv2.add_theme_font_size_override("font_size", 13)
	lmv2.add_theme_color_override("font_color", Color(C_GREEN_L.r, C_GREEN_L.g, C_GREEN_L.b, 0.70))
	setup_panel.add_child(lmv2)

	# ── Nota pistola ──
	var nota := Label.new()
	nota.text = "⚠  Pistola: 10 balas por partida sin recarga. ¡Úsalas bien!"
	nota.set_anchors_preset(Control.PRESET_TOP_WIDE)
	nota.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	nota.position = Vector2(0, 510)
	nota.add_theme_font_size_override("font_size", 14)
	nota.add_theme_color_override("font_color", Color(0.95, 0.75, 0.20, 0.90))
	setup_panel.add_child(nota)

	# ── Botón Jugar ──
	var btn2 := Button.new(); btn2.text = "▶  ¡JUGAR!"
	btn2.position = Vector2(490, 548); btn2.size = Vector2(300, 62)
	btn2.add_theme_font_size_override("font_size", 28)
	btn2.pressed.connect(_on_start_pressed); setup_panel.add_child(btn2)

	var inf := Label.new()
	inf.text = "5 goles para ganar  ·  ESPACIO = Pausa"
	inf.set_anchors_preset(Control.PRESET_TOP_WIDE)
	inf.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	inf.position = Vector2(0, 626)
	inf.add_theme_font_size_override("font_size", 13)
	inf.add_theme_color_override("font_color", Color(0.50, 0.50, 0.45, 0.75))
	setup_panel.add_child(inf)

	pause_block = ColorRect.new()
	pause_block.visible = false
	pause_block.set_anchors_preset(Control.PRESET_FULL_RECT)
	pause_block.color = Color(0, 0, 0, 0)
	pause_block.mouse_filter = Control.MOUSE_FILTER_STOP
	cl.add_child(pause_block)

	_set_game_ui(false)

func _mk_label(txt: String, pos: Vector2, fsz: int, col: Color, parent: Node) -> Label:
	var l := Label.new(); l.text = txt; l.position = pos
	l.add_theme_font_size_override("font_size", fsz)
	l.add_theme_color_override("font_color", col); parent.add_child(l); return l

func _mk_keybtn(x: float, y: float, w: float, parent: Node, default_label: String, slot: int) -> Button:
	var b := Button.new()
	b.text     = default_label
	b.position = Vector2(x, y); b.size = Vector2(w, 42)
	b.add_theme_font_size_override("font_size", 18)
	b.pressed.connect(func(): _on_key_btn_pressed(slot))
	parent.add_child(b)
	return b

# ── INPUT MAP (valores por defecto) ──────────────────────
func _ensure_input_map() -> void:
	var map : Dictionary = {
		"p1_up":KEY_W, "p1_down":KEY_S, "p1_left":KEY_A, "p1_right":KEY_D,
		"p1_shoot":KEY_F, "p1_kick":KEY_G,
		"p2_up":KEY_UP, "p2_down":KEY_DOWN, "p2_left":KEY_LEFT, "p2_right":KEY_RIGHT,
		"p2_shoot":KEY_K, "p2_kick":KEY_L,
		"pause":KEY_SPACE,
		"quit_action":KEY_ESCAPE,
	}
	for action : String in map.keys():
		if not InputMap.has_action(action): InputMap.add_action(action)
		var ev := InputEventKey.new(); ev.physical_keycode = map[action] as Key
		InputMap.action_add_event(action, ev)
